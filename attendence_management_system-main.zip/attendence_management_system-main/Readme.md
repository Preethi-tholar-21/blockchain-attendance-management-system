# Attendence-Management-System-on-Blockchain-Using-Solidity

create a account on Metamask or any other wallet
take some Ether on it,from your Friend(free available on interner sites)
Compile "Attendence.sol" on https://remix.ethereum.org/,click on confirm transaction,take the hashcode of that transaction ,insert it into <HashCode Section> index.html file
Run the index.html file on your localhost.
follow the "BlockChainProjectDescription.pdf" file for performing varous operations.
